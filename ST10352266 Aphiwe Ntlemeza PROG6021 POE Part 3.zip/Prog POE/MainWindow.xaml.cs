﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Prog_POE
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes;

        public MainWindow()
        {
            InitializeComponent();
            recipes = new List<Recipe>();
        }

        private void AddRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            AddRecipeWindow addRecipeWindow = new AddRecipeWindow();
            if (addRecipeWindow.ShowDialog() == true)
            {
                recipes.Add(addRecipeWindow.Recipe);
                RecipesListBox.Items.Add(addRecipeWindow.Recipe);
            }
        }

        private void DisplayRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipesListBox.SelectedItem != null)
            {
                Recipe selectedRecipe = (Recipe)RecipesListBox.SelectedItem;
                RecipeDetailsWindow detailsWindow = new RecipeDetailsWindow();
                detailsWindow.DisplayRecipeDetails(selectedRecipe);
                detailsWindow.Show();
            }
            else
            {
                MessageBox.Show("Please select a recipe to display.");
            }
        }

        private void FilterByIngredientButton_Click(object sender, RoutedEventArgs e)
        {
            FilterWindow filterWindow = new FilterWindow("ingredient");
            if (filterWindow.ShowDialog() == true)
            {
                string ingredientName = filterWindow.FilterText;
                var filteredRecipes = recipes.Where(r => r.Ingredients.Any(i => i.Name.Equals(ingredientName, StringComparison.OrdinalIgnoreCase))).ToList();
                DisplayFilteredRecipes(filteredRecipes);
            }
        }

        private void FilterByFoodGroupButton_Click(object sender, RoutedEventArgs e)
        {
            FilterWindow filterWindow = new FilterWindow("food group");
            if (filterWindow.ShowDialog() == true)
            {
                string foodGroup = filterWindow.FilterText;
                var filteredRecipes = recipes.Where(r => r.Ingredients.Any(i => i.FoodGroup.Equals(foodGroup, StringComparison.OrdinalIgnoreCase))).ToList();
                DisplayFilteredRecipes(filteredRecipes);
            }
        }

        private void DisplayFilteredRecipes(List<Recipe> filteredRecipes)
        {
            RecipesListBox.Items.Clear();
            foreach (var recipe in filteredRecipes)
            {
                RecipesListBox.Items.Add(recipe);
            }

            if (filteredRecipes.Count == 0)
            {
                MessageBox.Show("No recipes found matching the filter criteria.");
            }
        }
    }
}