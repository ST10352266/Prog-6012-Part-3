﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog_POE
{
    public class Recipe
    {
        public string NameOfRecipe { get; set; }
        public List<Ingredient> Ingredients { get; set; }
        public List<string> CookingSteps { get; set; }

        public Recipe()
        {
            Ingredients = new List<Ingredient>();
            CookingSteps = new List<string>();
        }
    }

    public class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string UnitOfMeasurement { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }
    }
}
