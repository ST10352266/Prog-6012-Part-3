﻿using Prog_POE;
using System;
using System.Collections.Generic;

public delegate void RecipeCaloriesExceededEventHandler(string recipeName, double totalCalories);

public class Recipe
{
    public string NameOfRecipe { get; set; }
    public List<Ingredient> Ingredients { get; set; }
    public List<string> CookingSteps { get; set; }

    public event RecipeCaloriesExceededEventHandler CaloriesExceeded;

    public Recipe()
    {
        Ingredients = new List<Ingredient>();
        CookingSteps = new List<string>();
    }

    public double TotalCalories => Ingredients.Sum(ingredient => ingredient.Calories);

    public void CheckCalories()
    {
        if (TotalCalories > 300 && CaloriesExceeded != null)
        {
            CaloriesExceeded(NameOfRecipe, TotalCalories);
        }
    }
}
