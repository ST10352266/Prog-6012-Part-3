﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Prog_POE
{
    /// <summary>
    /// Interaction logic for FilterWindow.xaml
    /// </summary>
    public partial class FilterWindow : Window
    {
        public string FilterText { get; private set; }

        public FilterWindow(string filterType)
        {
            InitializeComponent();
            FilterPromptTextBlock.Text = $"Enter {filterType} to filter by:";
            DataContext = this; // Add this line to bind DataContext for TextBox
        }

        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            FilterText = FilterTextBox.Text;
            this.DialogResult = true;
            this.Close();
        }
    }
}