Instructions on how to compile the software.
Extract the file containing all the files related to this project.
Open all the file on Visual Studio 2022. Go to the MainWindow.xaml and run the software.