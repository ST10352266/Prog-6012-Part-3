﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Prog_POE
{
    /// <summary>
    /// Interaction logic for AddRecipeWindow.xaml
    /// </summary>
    public partial class AddRecipeWindow : Window
    {
        public Recipe Recipe { get; private set; }

        public AddRecipeWindow()
        {
            InitializeComponent();
            Recipe = new Recipe();
            DataContext = this;
        }

        private void AddIngredientButton_Click(object sender, RoutedEventArgs e)
        {
            Ingredient ingredient = new Ingredient
            {
                Name = IngredientNameTextBox.Text,
                Quantity = double.TryParse(IngredientQuantityTextBox.Text, out double quantity) ? quantity : 0,
                UnitOfMeasurement = IngredientUnitTextBox.Text,
                Calories = double.TryParse(IngredientCaloriesTextBox.Text, out double calories) ? calories : 0,
                FoodGroup = IngredientFoodGroupTextBox.Text
            };

            Recipe.Ingredients.Add(ingredient);
            IngredientsListBox.Items.Add($"{ingredient.Name} - {ingredient.Quantity} {ingredient.UnitOfMeasurement} - {ingredient.Calories} calories");

            ClearIngredientFields();
        }

        private void AddStepButton_Click(object sender, RoutedEventArgs e)
        {
            string step = CookingStepTextBox.Text;
            if (!string.IsNullOrEmpty(step))
            {
                Recipe.CookingSteps.Add(step);
                CookingStepsListBox.Items.Add(step);
                CookingStepTextBox.Clear();
            }
        }

        private void SaveRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            Recipe.NameOfRecipe = RecipeNameTextBox.Text;
            Recipe.CheckCalories();
            this.DialogResult = true;
            this.Close();
        }

        private void ClearIngredientFields()
        {
            IngredientNameTextBox.Clear();
            IngredientQuantityTextBox.Clear();
            IngredientUnitTextBox.Clear();
            IngredientCaloriesTextBox.Clear();
            IngredientFoodGroupTextBox.Clear();
        }
    }
}
